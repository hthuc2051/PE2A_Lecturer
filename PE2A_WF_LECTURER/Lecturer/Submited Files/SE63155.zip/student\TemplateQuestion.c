


/*
 * Include your working files with syntax ! 
 * #include "student/fileName.c" FILE MUST NOT CONTAINS main() method !
 */

float template_findAreaOfRectangle(float width, float height) {
    return computeArea(width, height);
}

void template_checkBubbleSort(int arr[], int n) {
    bubbleSort(arr, n);
}

int template_checkLeapYear(int year) {
    return checkLeapYear(year);
}

int template_findTheLargestNumInArray(int arr[], int n) {
    return findTheLargestInArray(arr, n);
}

